d = 2.5
razao = 2

v = d * razao
print(f'A velocidade do caminhão {v}m/s')